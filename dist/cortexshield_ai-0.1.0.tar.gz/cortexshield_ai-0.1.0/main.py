from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from src.cortexshield import CortexShield

app = FastAPI(title="🧠🛡️ CortexShield AI v0.1.0")

shield = CortexShield()

class InferenceRequest(BaseModel):
    prompt: str
    sensitivity: str = "medium"

@app.post("/protect/infer")
async def infer(request: InferenceRequest):
    result = shield.protect(request.prompt, sensitivity=request.sensitivity)
    return result

@app.get("/")
async def root():
    return {"message": "🧠🛡️ CortexShield AI Active", "docs": "/docs"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
