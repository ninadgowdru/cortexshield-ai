"""
CortexShield AI - Main user interface
"""

from ..detectors.prompt_injection import PromptInjectionDetector
from ..core.model_wrapper import CortexShieldWrapper

class CortexShield:
    def __init__(self, sensitivity: str = "medium"):
        self.detector = PromptInjectionDetector()
        self.wrapper = CortexShieldWrapper()
        self.sensitivity = sensitivity
    
    def protect(self, prompt: str, model_id: str = "distilgpt2") -> dict:
        threat_report = self.detector.analyze(prompt, self.sensitivity)
        
        if threat_report["is_threat"]:
            return {
                "blocked": True,
                "reason": threat_report["explanation"],
                "immune_score": 0.0
            }
        
        response = self.wrapper.local_inference(prompt, model_id)
        return {
            "blocked": False,
            "response": response,
            "immune_score": self.detector.calculate_immune_score(threat_report),
            "threat_report": threat_report
        }
