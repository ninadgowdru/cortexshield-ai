"""
🧠🛡️ CortexShield AI - Simple AI protection
pip install cortexshield-ai
shield = CortexShield()
result = shield.protect("Hello world")
"""

from .core.cortexshield import CortexShield
from .detectors.prompt_injection import PromptInjectionDetector

__version__ = "0.1.0"
__all__ = ["CortexShield", "PromptInjectionDetector"]
